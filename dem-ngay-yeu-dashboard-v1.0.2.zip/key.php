<?php
define('License', 'mr7OQJXK0lMyOzdCs4O0BGF0ChHMyemz'); // Khóa giấy phép của bạn
