<link rel="stylesheet" id="css-main" href="./assets/oneui/css/oneui.min-5.6.css"> <!--MainCss-->
    <body onLoad="Notifykey()">
            <div class="content mb-3 animated fadeIn">
                <div class="block block-rounded h-100 mb-4">
                    <div class="content content-full">
                        <div class="row justify-content-center">
                            <div class="col-md-8 col-lg-6 col-xl-4 py-6">
                                <div class="text-center">
                                    <p><i class="fa fa-3x fa-gear text-primary fa-spin"></i></p>
                                    <h1 class="h4 mb-1">Tạm Thời Bảo Trì :(</h1><br>
                                    <span class="h6 fw-normal text-muted mb-3" style="color:green !important;">Nếu Cần Sự Hỗ Trợ, Hãy Liên Hệ Cho QTV</span>
                                    <h2 style="color:red !important;" class="h6 fw-danger text-muted mb-3">Quản Trị Viên Tạm Thời Bảo Trì Trang Này</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="block-content block-content-full ">
                        <div class="" style="display: block;margin-top:-80px;">
                            <div class="chatBox-content" id="article-wrapper">
                                <div class="text-center" id="">
                                    <img height="250" src="https://i.pinimg.com/564x/13/69/bc/1369bcc94fd6b721d56860f18d9a6e5f.jpg">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer id="page-footer" class="bg-body-light fixed-bottom">
        <div class="content py-3">
        <div class="row fs-sm">
            <div class="col-sm-6 order-sm-2 py-1 text-center text-sm-end">
                Crafted with <i class="fa fa-heart text-danger"></i> by <a class="fw-semibold" href="https://thanhdieu.com" target="_blank">WusThanhDieu</a>
            </div>
            <div class="col-sm-6 order-sm-1 py-1 text-center text-sm-start">
                <a class="fw-semibold" href="https://thanhdieu.com" target="_blank">ThanhDieu.Com</a> ©
                <span data-toggle="year-copy" class="js-year-copy-enabled">2023</span>
            </div>
        </div>
    </div>
</footer>